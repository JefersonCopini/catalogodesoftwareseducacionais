export default function Admin(){
    return (
        <div>
        <h1 className="text-center text-xl">Área Administrativa</h1>
        <a href="/admin/Car">Listar Carros</a>
        <a href="/admin/Car/new">Cadastrar Carros</a>
        

    

        </div>
        
    )
}