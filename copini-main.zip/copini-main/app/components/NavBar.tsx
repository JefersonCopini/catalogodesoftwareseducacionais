export default function NavBar(){
    return(
        <div className="p-12 flex justify-between items-center">
           
            <h1>Navegação</h1>
            <h1>Nome Usuario</h1>
        </div>

    )
}