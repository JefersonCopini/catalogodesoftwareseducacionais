export default function Aside() {
    return (
        <div className="w-1/6">
            <a href="/admin/Car">Listar Carros</a> <br></br>
            <a href="/admin/Car/new">Cadastrar Carros </a>

        </div>
    )
}