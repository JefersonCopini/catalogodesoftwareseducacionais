import Image from 'next/image'


export default function Home() {
  return (
    
    <div className="bg-[#3d3d3d]">
      <div className="max-w-[1440px] m-auto ">
      
    <h1 className="text-center text-xl">Aplicação de carros</h1>
    
    <a className="text-center text-white text-xl" href="/admin"> CLIQUE AQUI PARA ENTRAR NO SISTEMA</a>
    </div>
    </div>
    
  )
}
